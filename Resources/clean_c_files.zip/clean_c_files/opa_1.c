void opa() {
  rr++;
}