
void opa() {
  rr++;
}